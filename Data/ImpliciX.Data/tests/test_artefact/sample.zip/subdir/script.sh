#!/bin/bash
set -euo pipefail

echo 42