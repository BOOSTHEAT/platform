setValue devices:bh20:serial_number          "the_serial_number"
setValue general:harmony:id_scope            "the_id_scope"
setValue general:harmony:device_key          "the_device_key"

BOILER_ENVIRONMENT=dev
