#!/bin/sh
set -eu

SCRIPT_FOLDER="$(dirname "$0")"
INSTALL_COMMANDS="${1:-${SCRIPT_FOLDER}/factory.sh}"

. "${SCRIPT_FOLDER}/redis_tools.sh"

echo "CLEAR ALL SETTINGS"
selectDb 2
clearAllDbContent

echo "FACTORY PERSONALIZATION"
selectDb 3
. "${INSTALL_COMMANDS}"

echo "BOILER_ENVIRONMENT=${BOILER_ENVIRONMENT}" > "${SCRIPT_FOLDER}/../boiler_app.env"
cat "${SCRIPT_FOLDER}/../boiler_app.env"



