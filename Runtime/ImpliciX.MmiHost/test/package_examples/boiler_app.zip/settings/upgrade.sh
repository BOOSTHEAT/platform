#!/bin/sh
set -eu

SCRIPT_FOLDER="$(dirname "$0")"

. "${SCRIPT_FOLDER}/redis_tools.sh"

echo "CLEAR VERSION SETTINGS"
selectDb 2
clearDbContent

cp /tmp/boiler_app.env "${SCRIPT_FOLDER}/../"
