#!/bin/sh
set -eu

# VARIABLES
REDIS_HOST=${REDIS_HOST:-"127.0.0.1"}
REDIS_PORT=${REDIS_PORT:-6379}
REDIS_DB=${REDIS_DB:-0}
DEFAULT_AT=${DEFAULT_AT:-"09:00:00.0000000"}

# FUNCTIONS
callRedis() {
  redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" -n "$REDIS_DB" "$@"
}

clearAllDbContent() {
  while [ "$(callRedis DBSIZE)" != "0" ]
  do
    echo "FLUSHALL"
    callRedis FLUSHALL > /dev/null
  done
}

selectDb() {
  export REDIS_DB=$1
}

clearDbContent() {
  while [ "$(callRedis DBSIZE)" != "0" ]
  do
    echo "FLUSHDB ${REDIS_DB}" 
    callRedis FLUSHDB > /dev/null
  done
}

setFunction() {
  urn="$1"
  shift
  callRedis HMSET "$urn" at "${DEFAULT_AT}" "$@" > /dev/null
}

setValue() {
  setFunction "$1" value "$2" > /dev/null
}
